# Discord Token Login
----
## How do I use this?
Open Chrome, right click on the bookmark bar, paste.
Go to https://discord.com, press on the new bookmark, paste the token, press OK
----
## Creator
Dont know who made it first, dont care lol

# Discord Token Login
----
## How do I use this?
Open Chrome, right click on the bookmark bar, paste.
Go to https://discord.com, press on the new bookmark, paste the token, press OK
----
## Creator
HR_1738Gz#1738
